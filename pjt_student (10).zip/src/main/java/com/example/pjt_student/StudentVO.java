package com.example.pjt_student;

//학생 한명의 정보 추상화 VO(Value-Object)
public class StudentVO {
    int id;
    String name;
    String email;
    String phone;
    String photo;
    String memo;
}

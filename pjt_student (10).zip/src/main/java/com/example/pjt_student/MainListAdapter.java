package com.example.pjt_student;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.res.ResourcesCompat;

import java.util.ArrayList;

public class MainListAdapter extends ArrayAdapter<StudentVO> {
    Context context;
    ArrayList<StudentVO> datas;//activity가 전달하는 항목 집합 데이터..
    int resId;//activity가 전달하는 항목 layout xml 정보..

    public MainListAdapter(Context context, int resId, ArrayList<StudentVO> datas){
        super(context, resId);
        this.context=context;
        this.datas=datas;
        this.resId=resId;
    }
    //항목 갯수를 판단하기 위해서 자동 호출..
    @Override
    public int getCount() {
        return datas.size();
    }
    //한 항목이 화면에 보일때 마다 호출.. 항목 구성 목적으로..
    //==>한 항목 구성 알고리즘..
    //==>성능이슈 고려...
    //position : 항목  index....
    //View : 항목을 구성하기 위한 root 객체를 리턴하면.. 그 객체부터 하위 객체들이 항목에 출력..
    //convertView : 해당 항목을 구성하기 위해서 재사용할 view가 없다면...null
    //항목을 구성하기 위해서 리턴 시켰던 root  객체로 화면 찍고.. 내부적으로 메모리에 유지했다가..
    //재사용 가능한 범주에서 전달해 준다..
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if(convertView==null){
            LayoutInflater inflater=(LayoutInflater)context.getSystemService(
                    Context.LAYOUT_INFLATER_SERVICE);
            convertView=inflater.inflate(resId, null);

            MainListWrapper wrapper=new MainListWrapper(convertView);
            //android모든 view에는 개발자 임의 데이터(non-visible) 저장 가능..
            //그 view가 메모리에 지속만 된다면 언제든지 획득 가능...
            convertView.setTag(wrapper);//setTag(key, value)
        }

        MainListWrapper wrapper=(MainListWrapper)convertView.getTag();

        ImageView studentImageView = wrapper.studentImageView;
        TextView nameView=wrapper.nameView;
        final ImageView phoneView=wrapper.phoneView;

        final StudentVO vo=datas.get(position);

        nameView.setText(vo.name);

        //camera 로 찍은 사진 이미지를 로딩하려고 하고 있다.. 사이즈 너무 크다.. OOM 문제 발생한다.
        //이미지 데이터 사이즈를 줄여서 로딩해야 한다..
        if(vo.photo != null && !vo.photo.equals("")){
            BitmapFactory.Options options=new BitmapFactory.Options();
            options.inSampleSize=10;//10분의 1로 줄여서 로딩한다..
            Bitmap bitmap= BitmapFactory.decodeFile(vo.photo, options);
            if(bitmap != null){
                studentImageView.setImageBitmap(bitmap);
            }
        }else {
            studentImageView.setImageDrawable(ResourcesCompat.getDrawable(
                    context.getResources(), R.drawable.ic_student_small, null));
        }

        studentImageView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                LayoutInflater inflater=(LayoutInflater)context.getSystemService(
                        Context.LAYOUT_INFLATER_SERVICE);
                View dialogRoot=inflater.inflate(R.layout.dialog_student_image, null);
                ImageView dialogImageView=dialogRoot.findViewById(R.id.dialog_image);

                if(vo.photo != null && !vo.photo.equals("")){
                    BitmapFactory.Options options=new BitmapFactory.Options();
                    options.inSampleSize=10;//10분의 1로 줄여서 로딩한다..
                    Bitmap bitmap= BitmapFactory.decodeFile(vo.photo, options);
                    if(bitmap != null){
                        dialogImageView.setImageBitmap(bitmap);
                    }
                }else {
                    dialogImageView.setImageDrawable(ResourcesCompat.getDrawable(
                            context.getResources(), R.drawable.ic_student_large, null));
                }

                AlertDialog.Builder builder=new AlertDialog.Builder(context);
                builder.setView(dialogRoot);
                AlertDialog dialog=builder.create();
                dialog.show();
            }
        });

        return convertView;
    }
}

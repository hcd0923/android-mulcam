package com.example.pjt_student;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

public class MyView extends View {
    Context context;
    int score;
    int color;

    //view 를 activity 개발자가 java 에서 직접 생성해서 이용한다면.....
    //==>생성자는 하나만...
    //view 를 activity 개발자가 layout xml 등록해서 이용한다면.....
    //==>개발자 코드로 생성되는게 아니다.. 상황에 따라 호출되는 생성자가 다르다...
    //==>layout xml 등록에 의해 정상적으로 생성 이용되게 하려면 생성자 3개 모두 정의해 주어야...
    public MyView(Context context){
        super(context);
        this.context=context;
        init(null);
    }
    //layout xml 에 속성이 지정된 경우.. 속성값 전달 목적으로...
    public MyView(Context context, AttributeSet attributeSet){
        super(context, attributeSet);
        this.context=context;
        init(attributeSet);
    }
    //layout xml 등록시 style까지 선언한 경우..
    public MyView(Context context, AttributeSet attributeSet, int style){
        super(context, attributeSet, style);
        this.context=context;
        init(attributeSet);
    }

    private void init(AttributeSet attributeSet){
        if(attributeSet != null){
            //속성 값 추출..
            TypedArray array=context.obtainStyledAttributes(attributeSet, R.styleable.AAA);
            color=array.getColor(R.styleable.AAA_scoreColor, Color.YELLOW);
        }
    }
    //activity 에서 score 전달 목적으로 호출...
    public void setScore(int score){
        this.score=score;
        //새로운 score가 전달... 그림 다시 그려야 한다..
        invalidate();//자동으로  onDraw() 자동 호출...
    }
    //view 출력을 그리기 위해 자동 호출...
    @Override
    protected void onDraw(Canvas canvas) {
        //화면 지우고..
        canvas.drawColor(Color.alpha(Color.CYAN));
        //사각형을 그리기 위한 정보..
        RectF rectF=new RectF(15, 15, 70, 70);
        //그리기 옵션..
        Paint paint=new Paint();
        paint.setColor(Color.GRAY);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(15);
        paint.setAntiAlias(true);
        //기본원 회색으로 360도 그리고..
        canvas.drawArc(rectF, 0, 360, false, paint);
        //score 각도 계산..
        float endAngle=(360*score)/100;
        //score 원 그리기..
        paint.setColor(color);
        //0도가 동쪽이다.. 북쪽부터 그릴려고 -90
        canvas.drawArc(rectF, -90, endAngle, false, paint);
    }
}

package com.example.pjt_student;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    ImageView studentImageView;
    TextView nameView;
    TextView phoneView;
    TextView emailView;

    TabHost host;

    int studentId=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        initData();
        initTab();
    }

    private void initData(){
        studentImageView=findViewById(R.id.detail_student_image);
        nameView=findViewById(R.id.detail_name);
        phoneView=findViewById(R.id.detail_phone);
        emailView=findViewById(R.id.detail_email);

        DBHelper helper=new DBHelper(this);
        SQLiteDatabase db=helper.getReadableDatabase();
        //Cursor : select row 집합객체...
        //cursor를 움직여서 row를 선택하고 선택된 row 의 column data 추출...
        Cursor cursor=db.rawQuery("select * from tb_student where _id=?",
                new String[]{String.valueOf(studentId)});

        String photo=null;

        //moveXXX() row 선택 함수.. 선택되면  true, 안되면 false
        if(cursor.moveToFirst()){
            nameView.setText(cursor.getString(1));
            emailView.setText(cursor.getString(2));
            phoneView.setText(cursor.getString(3));
            photo=cursor.getString(4);
        }
        db.close();

    }

    private void initTab(){
        host=findViewById(R.id.host);
        //너네 하위에 FrameLayout 과 TabWidget 이 선언되어 있을거다.. 선언된데로 초기화 하라..
        host.setup();

        //tab 하나가 TabSpec 으로 표현되고.. 이 안에.. button 과 button 클릭시 나올 content가
        //결합... 그 버튼 누르면 그 content 가 나온다..
        //매개변수 문자열은 개발자 임의 식별자 문자열.. 유저가 tab 화면 조정시 프로그램에서
        //어떤 탭화면을 연건지 확인할때 사용
        TabHost.TabSpec spec=host.newTabSpec("tab1");
        spec.setIndicator("score");//button
        spec.setContent(R.id.detail_score_list);//content
        host.addTab(spec);

        spec=host.newTabSpec("tab2");
        spec.setIndicator("chart");//button
        spec.setContent(R.id.detail_score_chart);//content
        host.addTab(spec);

        spec=host.newTabSpec("tab3");
        spec.setIndicator("add");//button
        spec.setContent(R.id.detail_score_add);//content
        host.addTab(spec);

        spec=host.newTabSpec("tab4");
        spec.setIndicator("memo");//button
        spec.setContent(R.id.detail_memo);//content
        host.addTab(spec);
    }
}
